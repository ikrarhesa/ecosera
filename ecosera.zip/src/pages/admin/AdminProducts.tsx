import { useState, useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { Plus, ArrowLeft, Package } from "lucide-react";
import { supabase } from "../../lib/supabase";

interface ProductRow {
    id: string;
    name: string;
    slug: string;
    price: number;
    is_active: boolean;
}

const fmtIDR = (n: number) =>
    new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);

export default function AdminProducts() {
    const { seller_id } = useParams<{ seller_id: string }>();
    const [products, setProducts] = useState<ProductRow[]>([]);
    const [shopName, setShopName] = useState("");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        if (!seller_id) return;
        (async () => {
            setLoading(true);

            // Fetch shop name
            const { data: sellerData } = await supabase
                .from("sellers")
                .select("name")
                .eq("id", seller_id)
                .single();
            if (sellerData) setShopName(sellerData.name);

            // Fetch products for this seller
            const { data, error: fetchErr } = await supabase
                .from("products")
                .select("id, name, slug, price, is_active")
                .eq("seller_id", seller_id)
                .order("created_at", { ascending: false });
            if (fetchErr) {
                console.error("[AdminProducts]", fetchErr);
                setError(fetchErr.message);
            } else {
                setProducts((data as ProductRow[]) || []);
            }
            setLoading(false);
        })();
    }, [seller_id]);

    return (
        <div className="min-h-screen relative overflow-hidden pb-8">
            {/* Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-blue-100 to-blue-200">
                <div className="absolute top-0 -left-4 w-72 h-72 bg-blue-400 rounded-full mix-blend-multiply filter blur-xl opacity-25" />
                <div className="absolute top-0 -right-4 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-25" />
            </div>

            <div className="relative z-10 px-4 pt-4 max-w-4xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                        <Link
                            to="/admin/shops"
                            className="p-2 rounded-lg bg-white border border-slate-200 hover:bg-slate-50 transition-colors"
                        >
                            <ArrowLeft className="h-5 w-5 text-slate-600" />
                        </Link>
                        <div>
                            <div className="flex items-center gap-2">
                                <Package className="h-6 w-6 text-blue-600" />
                                <h1 className="text-xl font-bold text-slate-900">Produk</h1>
                            </div>
                            {shopName && <p className="text-sm text-slate-600 mt-0.5">{shopName}</p>}
                        </div>
                    </div>

                    <Link
                        to={`/admin/shops/${seller_id}/products/new`}
                        className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white text-sm font-medium transition-all shadow-md"
                    >
                        <Plus className="h-4 w-4" />
                        Tambah Produk
                    </Link>
                </div>

                {/* Content */}
                {loading && <div className="text-center py-12 text-slate-600">Memuat produk…</div>}
                {error && (
                    <div className="rounded-xl bg-red-50 border border-red-200 p-4 mb-6 text-red-700 text-sm">{error}</div>
                )}

                {!loading && !error && (
                    <div className="bg-white/70 backdrop-blur-md rounded-xl shadow-lg border border-white/20 p-4">
                        {products.length === 0 ? (
                            <p className="text-sm text-slate-500 py-8 text-center">
                                Belum ada produk untuk toko ini. Klik "Tambah Produk" untuk memulai.
                            </p>
                        ) : (
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead>
                                        <tr className="border-b border-slate-200 text-left text-slate-600">
                                            <th className="pb-2 pr-4 font-medium">Nama</th>
                                            <th className="pb-2 pr-4 font-medium">Slug</th>
                                            <th className="pb-2 pr-4 font-medium text-right">Harga</th>
                                            <th className="pb-2 font-medium text-center">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {products.map((p) => (
                                            <tr key={p.id} className="border-b border-slate-100 hover:bg-white/50 transition-colors">
                                                <td className="py-2.5 pr-4 font-medium text-slate-900">{p.name}</td>
                                                <td className="py-2.5 pr-4 font-mono text-xs text-slate-600">{p.slug}</td>
                                                <td className="py-2.5 pr-4 text-right tabular-nums">{fmtIDR(p.price)}</td>
                                                <td className="py-2.5 text-center">
                                                    <span
                                                        className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${p.is_active
                                                                ? "bg-green-100 text-green-700"
                                                                : "bg-slate-100 text-slate-500"
                                                            }`}
                                                    >
                                                        {p.is_active ? "Aktif" : "Nonaktif"}
                                                    </span>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
