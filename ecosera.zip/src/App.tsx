
// src/App.tsx
import { Routes, Route, Navigate } from "react-router-dom";
import Home from "./pages/Home";
import Etalase from "./pages/Etalase";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import ELearning from "./pages/ELearning";
import ModuleDetail from "./pages/ModuleDetail";
import AdminDashboard from "./pages/AdminDashboard";
import AdminShops from "./pages/admin/AdminShops";
import AdminProducts from "./pages/admin/AdminProducts";
import AdminProductNew from "./pages/admin/AdminProductNew";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/etalase" element={<Etalase />} />
      <Route path="/product/:slug" element={<ProductDetail />} />
      <Route path="/cart" element={<Cart />} />
      <Route path="/e-learning" element={<ELearning />} />
      <Route path="/e-learning/:moduleId" element={<ModuleDetail />} />
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/admin/shops" element={<AdminShops />} />
      <Route path="/admin/shops/:seller_id/products" element={<AdminProducts />} />
      <Route path="/admin/shops/:seller_id/products/new" element={<AdminProductNew />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
