// src/services/products.ts
import { Product } from "../types/product";
import { supabase } from "../lib/supabase";

const PLACEHOLDER = "https://placehold.co/800x800/png?text=Ecosera"; // Placeholder image URL

// Function to normalize the product data from Supabase
function normalize(raw: any): Product {
  const stockRaw = raw.stock ?? raw.inventory ?? raw.qty ?? null;
  const stockParsed = stockRaw == null ? 999 : Number.parseInt(String(stockRaw), 10);

  // Collect image URLs with a fallback
  const imgs = raw.images || (raw.thumb ? [raw.thumb] : [PLACEHOLDER]);  // Use thumb if images not available
  const primary = imgs[0] || PLACEHOLDER;

  const base: Product = {
    id: String(raw.id),
    slug: raw.slug ?? undefined,
    name: String(raw.name || "Unknown Product"),  // Ensure product has a name
    price: Number(raw.price ?? 0),  // Ensure price is a number
    unit: String(raw.unit ?? "pcs"),  // Ensure unit is provided
    stock: Number.isFinite(stockParsed) ? stockParsed : 999,  // Ensure stock is a valid number
    image: primary,
    images: imgs,
    description: raw.description ?? "No description available",  // Default description if missing
    category: String(raw.category ?? "general"),  // Default category if missing
    sellerName: raw.sellerName ?? "UMKM Lokal",  // Default seller name
    sellerPhone: raw.sellerPhone ?? "",  // Default phone if missing
    location: raw.location ?? "Muara Enim",  // Default location
    rating: Number(raw.rating ?? 4.8),  // Default rating if missing
    sold: Number(raw.sold ?? 0),  // Default sold count if missing
    tags: Array.isArray(raw.tags) ? raw.tags : [],  // Ensure tags are an array
    seller_id: raw.seller_id ?? null,
  };

  // Optional flags
  base.featured = !!raw.featured;
  base.available = raw.is_active !== false;

  return base;
}

// Function to fetch and normalize all products
export async function getAllProducts(): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("is_active", true);

    if (error) {
      console.error("Error fetching all products from Supabase", error);
      return [];
    }

    return (data || []).map(normalize);
  } catch (err) {
    console.error("Unexpected error fetching all products:", err);
    return [];
  }
}

// Function to get a product by its Slug
export async function getProductBySlug(slug: string): Promise<Product | null> {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("slug", slug)
      .single();

    if (error) {
      console.error(`Error fetching product with slug ${slug}:`, error);
      return null;
    }
    return data ? normalize(data) : null;
  } catch (err) {
    console.error("Unexpected error fetching product:", err);
    return null;
  }
}

// Function to get related products based on category
export async function getRelatedProducts(category: string, excludeId?: string, limit = 8): Promise<Product[]> {
  const all = await getAllProducts();
  const base = all.filter(p => p.id !== excludeId);
  const main = excludeId ? all.find(x => x.id === excludeId) : null;
  const mainTags = new Set((main?.tags ?? []).map(t => (t ?? "").toLowerCase()));

  const score = (p: Product) => {
    let sc = 0;
    if (category && p.category === category) sc += 2;
    if (p.tags?.length && mainTags.size) {
      let shared = 0;
      for (const t of p.tags) {
        if (mainTags.has((t ?? "").toLowerCase())) { shared++; if (shared >= 3) break; }
      }
      sc += shared;
    }
    if ((p.stock ?? 0) <= 0) sc -= 2;
    return sc;
  };

  return base
    .map(p => ({ p, s: score(p) }))
    .filter(x => x.s > -2)
    .sort((a, b) => {
      if (b.s !== a.s) return b.s - a.s;
      const sa = a.p.stock ?? 0, sb = b.p.stock ?? 0;
      if (sb !== sa) return sb - sa;
      const ra = a.p.rating ?? 0, rb = b.p.rating ?? 0;
      return rb - ra;
    })
    .slice(0, limit)
    .map(x => x.p);
}

// Function to get all images of a product (returns array of image URLs)
export function allImagesOf(p?: Product | null): string[] {
  if (!p) return [PLACEHOLDER];
  const arr = p.images?.length ? p.images : (p.image ? [p.image] : []);
  return arr.length ? arr : [PLACEHOLDER];
}

// Function to get the primary image of a product
export function primaryImageOf(p?: Product | null): string {
  if (!p) return PLACEHOLDER;
  return p.image || (p.images?.[0]) || PLACEHOLDER;
}

// Exporting additional required functions
export async function getFeaturedProducts(): Promise<Product[]> {
  try {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("featured", true)
      .eq("is_active", true);

    if (error) {
      console.error("Error fetching featured products:", error);
      return [];
    }
    return (data || []).map(normalize);
  } catch (err) {
    console.error("Unexpected error fetching featured products:", err);
    return [];
  }
}
