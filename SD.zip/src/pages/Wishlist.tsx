import { useWishlist } from "../context/WishlistContext";
import ProductCard from "../components/ProductCard";
import Navbar from "../components/Navbar";
import { Heart } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Wishlist() {
    const { wishlist } = useWishlist();
    const navigate = useNavigate();

    return (
        <>
            <Navbar />
            <div className="min-h-screen bg-[#F6F8FC] pb-28">
                <div className="sticky top-0 z-20 bg-white border-b border-slate-200">
                    <div className="px-4 py-3 flex items-center justify-between">
                        <div>
                            <div className="font-semibold text-slate-900 text-lg">Tersimpan</div>
                            {wishlist.length > 0 && (
                                <div className="text-xs text-slate-500">{wishlist.length} produk</div>
                            )}
                        </div>
                    </div>
                </div>

                <main className="px-4 pt-4">
                    {wishlist.length === 0 ? (
                        <div className="text-center mt-16">
                            <Heart className="h-16 w-16 text-slate-300 mx-auto mb-3" />
                            <p className="text-slate-500 font-medium">Belum ada yang disimpan</p>
                            <p className="text-slate-400 text-sm mt-1">Cari produk yang kamu suka dan simpan untuk nanti!</p>
                            <button
                                onClick={() => navigate("/")}
                                className="mt-4 px-6 py-2 rounded-xl bg-blue-500 text-white text-sm font-medium hover:bg-blue-600 transition-colors"
                            >
                                Mulai Belanja
                            </button>
                        </div>
                    ) : (
                        <div className="grid grid-cols-2 gap-3">
                            {wishlist.map((p) => (
                                <ProductCard key={p.id} product={p} />
                            ))}
                        </div>
                    )}
                </main>
            </div>
        </>
    );
}
