<<<<<<< HEAD
// src/services/products.ts
import { Product } from "../types/product";

const PLACEHOLDER = "https://placehold.co/800x800/png?text=Ecosera"; // Placeholder image URL

// Function to load products and ensure data integrity
=======
import type { Product } from "../types/product";

let cache: Product[] | null = null;
let indexById: Map<string, Product> | null = null;

const PLACEHOLDER = "https://placehold.co/800x800/png?text=Ecosera";

/** Load products.json from the src/data directory */
>>>>>>> 7edfccddadb209813f7a69e5a6308d535808fd36
async function loadProductsJSON(): Promise<any[]> {
  try {
    const mod: any = await import("../data/products.json");  // Dynamically import JSON
    return mod.default || mod;  // Return the default export if it exists
  } catch (e) {
    console.error("Failed to load products.json", e);
<<<<<<< HEAD
    return [];  // Return an empty array if the fetch fails
  }
}

// Function to normalize the product data and ensure integrity
=======
    return [];  // Return an empty array if there's an error
  }
}

/** Kumpulkan semua kemungkinan field gambar, lalu dedupe */
function collectImages(raw: any): string[] {
  const buckets: (string | string[] | null | undefined)[] = [
    raw.images, raw.photos, raw.gallery, raw.thumbnails, raw.pictures,
    raw.media, raw.assets,
    raw.images?.urls, // kadang nested
    [raw.thumbnail], [raw.cover], [raw.image], [raw.img], [raw.url], [raw.photo],
  ];
  const flat = buckets.flat().filter(Boolean) as string[];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const s of flat) {
    const v = String(s).trim();
    if (!v) continue;
    if (!seen.has(v)) { seen.add(v); out.push(v); }
  }
  return out;
}

/** Normalisasi 1 item */
>>>>>>> 7edfccddadb209813f7a69e5a6308d535808fd36
function normalize(raw: any): Product {
  const stockRaw = raw.stock ?? raw.inventory ?? raw.qty ?? null;
  const stockParsed = stockRaw == null ? 999 : Number.parseInt(String(stockRaw), 10);

<<<<<<< HEAD
  // Collect image URLs with a fallback
  const imgs = raw.images || (raw.thumb ? [raw.thumb] : [PLACEHOLDER]);  // Use thumb if images not available
  const primary = imgs[0] || PLACEHOLDER;

  const base: Product = {
    id: String(raw.id),
    name: String(raw.name || "Unknown Product"),  // Ensure product has a name
    price: Number(raw.price ?? 0),  // Ensure price is a number
    unit: String(raw.unit ?? "pcs"),  // Ensure unit is provided
    stock: Number.isFinite(stockParsed) ? stockParsed : 999,  // Ensure stock is a valid number
    image: primary,
    images: imgs,
    description: raw.description ?? "No description available",  // Default description if missing
    category: String(raw.category ?? "general"),  // Default category if missing
    sellerName: raw.sellerName ?? "UMKM Lokal",  // Default seller name
    sellerPhone: raw.sellerPhone ?? "",  // Default phone if missing
    location: raw.location ?? "Muara Enim",  // Default location
    rating: Number(raw.rating ?? 4.8),  // Default rating if missing
    tags: Array.isArray(raw.tags) ? raw.tags : [],  // Ensure tags are an array
  };

  // Optional flags
  base.featured = !!raw.featured;
  base.available = raw.available !== false;
=======
  const imgs = collectImages(raw);
  const primary = imgs[0] ?? PLACEHOLDER;

  const base: Product = {
    id: String(raw.id),
    name: String(raw.name),
    price: Number(raw.price ?? 0),
    unit: String(raw.unit ?? "pcs"),
    stock: Number.isFinite(stockParsed) ? stockParsed : 999,
    image: primary,
    images: imgs,
    description: raw.description ?? "",
    category: String(raw.category ?? "general"),
    sellerName: raw.sellerName ?? raw.seller ?? "UMKM Lokal",
    sellerPhone: raw.sellerPhone ?? raw.phone ?? "",
    location: raw.location ?? "Muara Enim",
    rating: Number(raw.rating ?? 4.8),
    tags: Array.isArray(raw.tags) ? raw.tags : [],
  };

  // pass-through flags opsional
  (base as any).featured = !!raw.featured;
  if (typeof raw.available !== "undefined") (base as any).available = raw.available !== false;
>>>>>>> 7edfccddadb209813f7a69e5a6308d535808fd36

  return base;
}

<<<<<<< HEAD
// Function to fetch and normalize all products
export async function getAllProducts(): Promise<Product[]> {
  let cache: Product[] | null = null;
  let indexById: Map<string, Product> | null = null;

  if (cache) return cache;
  const data = await loadProductsJSON();
  
  // Filter out invalid products and ensure data integrity
  const filtered = data.filter((p: any) => p?.available !== false);

  // Normalize the product data to ensure consistency
  cache = filtered.map(normalize);
  indexById = new Map(cache.map(p => [p.id, p]));
  
  return cache;
}

// Function to get a product by its ID
export async function getProductById(id: string): Promise<Product | null> {
  const all = await getAllProducts();
  return all.find((product) => product.id === id) ?? null;
}

// Function to get related products based on category
=======
/** Helpers untuk komponen */
export function primaryImageOf(p?: Product | null): string {
  if (!p) return PLACEHOLDER;
  return (p.images && p.images[0]) || p.image || PLACEHOLDER;
}
export function allImagesOf(p?: Product | null): string[] {
  if (!p) return [PLACEHOLDER];
  const arr = p.images?.length ? p.images : (p.image ? [p.image] : []);
  return arr.length ? arr : [PLACEHOLDER];
}

/** Load sekali dari /data/products.json dan cache (hanya available !== false) */
export async function getAllProducts(): Promise<Product[]> {
  if (cache) return cache;
  const data = await loadProductsJSON();
  const filtered = data.filter((p: any) => p?.available !== false);
  cache = filtered.map(normalize);
  indexById = new Map(cache.map(p => [p.id, p]));
  return cache;
}

export function invalidateProductsCache() { cache = null; indexById = null; }

export async function getFeaturedProducts(): Promise<Product[]> {
  const all = await getAllProducts();
  return all.filter((p: any) => !!(p as any).featured);
}

export async function getProductById(id: string): Promise<Product | null> {
  if (indexById) return indexById.get(id) ?? null;
  const all = await getAllProducts();
  return all.find(p => p.id === id) ?? null;
}

export async function searchProducts(q: string): Promise<Product[]> {
  const all = await getAllProducts();
  const s = (q ?? "").trim().toLowerCase();
  if (!s) return all;
  const contains = (v?: string) => (v ? v.toLowerCase().includes(s) : false);
  return all.filter(p =>
    contains(p.name) ||
    contains(p.id) ||
    contains(p.category) ||
    contains(p.sellerName) ||
    contains(p.location) ||
    (p.tags?.some(t => (t ?? "").toLowerCase().includes(s)) ?? false)
  );
}

>>>>>>> 7edfccddadb209813f7a69e5a6308d535808fd36
export async function getRelatedProducts(category: string, excludeId?: string, limit = 8): Promise<Product[]> {
  const all = await getAllProducts();
  const base = all.filter(p => p.id !== excludeId);
  const main = excludeId ? all.find(x => x.id === excludeId) : null;
  const mainTags = new Set((main?.tags ?? []).map(t => (t ?? "").toLowerCase()));

  const score = (p: Product) => {
    let sc = 0;
    if (category && p.category === category) sc += 2;
    if (p.tags?.length && mainTags.size) {
      let shared = 0;
      for (const t of p.tags) {
        if (mainTags.has((t ?? "").toLowerCase())) { shared++; if (shared >= 3) break; }
      }
      sc += shared;
    }
    if ((p.stock ?? 0) <= 0) sc -= 2;
    return sc;
  };

  return base
    .map(p => ({ p, s: score(p) }))
    .filter(x => x.s > -2)
    .sort((a, b) => {
      if (b.s !== a.s) return b.s - a.s;
      const sa = a.p.stock ?? 0, sb = b.p.stock ?? 0;
      if (sb !== sa) return sb - sa;
      const ra = a.p.rating ?? 0, rb = b.p.rating ?? 0;
      return rb - ra;
    })
    .slice(0, limit)
    .map(x => x.p);
}

<<<<<<< HEAD
// Function to get all images of a product (returns array of image URLs)
export function allImagesOf(p?: Product | null): string[] {
  if (!p) return [PLACEHOLDER];
  const arr = p.images?.length ? p.images : (p.image ? [p.image] : []);
  return arr.length ? arr : [PLACEHOLDER];
}

// Exporting additional required functions
export async function getFeaturedProducts(): Promise<Product[]> {
  const all = await getAllProducts();
  return all.filter((p: any) => p.featured);
=======
export async function getProductsByCategory(category: string, limit = 24): Promise<Product[]> {
  const all = await getAllProducts();
  return all.filter(p => p.category === category).slice(0, limit);
>>>>>>> 7edfccddadb209813f7a69e5a6308d535808fd36
}
