export const money = (n: number) => n.toLocaleString('id-ID');
