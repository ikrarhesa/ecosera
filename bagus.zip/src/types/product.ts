<<<<<<< HEAD
// src/types/product.ts
export interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;  // Add unit
  stock: number;  // Add stock
  image: string;  // Add image
  images: string[];
  description: string;  // Add description
  category: string;
  sellerName: string;  // Add sellerName
  sellerPhone: string;
  location: string;
  rating: number;
  tags: string[];
  featured?: boolean;
  available?: boolean;
}
=======
export type Product = {
  id: string;
  slug?: string; 
  name: string;
  price: number;
  rating: number;
  sold: number;
  thumb?: string;
  category?: string;
  tags?: string[];
  featured?: boolean;
  available?: boolean;
};
>>>>>>> 7edfccddadb209813f7a69e5a6308d535808fd36
